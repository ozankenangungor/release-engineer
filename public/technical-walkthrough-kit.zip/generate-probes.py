import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
HARNESS = ROOT / "harness"
package_path = HARNESS / "package.json"
package = json.loads(package_path.read_text())
package["devDependencies"]["ts-legacy"] = "npm:typescript@5.9.3"
package_path.write_text(json.dumps(package, indent=2) + "\n")

consumer = '''import * as z from "../../../sources/zod/VARIANT/packages/zod/src/v4/index.ts";
const record = z.record(z.string(), z.number());
type Input = z.input<typeof record>;
type Output = z.output<typeof record>;
const input: Input = { answer: 42 };
const output: Output = { answer: 42 };
const inputContract: Record<string, number> = input;
const outputContract: Record<string, number> = output;
// @ts-expect-error A wrong input value must be rejected, rather than silently becoming any.
const wrongInput: Input = { answer: "incorrect" };
// @ts-expect-error A wrong output value must be rejected too.
const wrongOutput: Output = { answer: "incorrect" };
void [inputContract, outputContract, wrongInput, wrongOutput];
'''
internal = '''import * as core from "../../../sources/zod/VARIANT/packages/zod/src/v4/core/index.ts";
interface Specialized extends core.$ZodRecordInternals<core.$ZodString<string>, core.$ZodNumber<number>> {
  optionalExtension?: "walkthrough";
}
type RequireTrue<T extends true> = T;
type BaseCompatibility = RequireTrue<Specialized extends core.$ZodTypeInternals<Record<string, number>, Record<string, number>> ? true : false>;
const input: Specialized["input"] = { answer: 42 };
const output: Specialized["output"] = { answer: 42 };
const compatible: BaseCompatibility = true;
// @ts-expect-error Extension must retain the inferred number output contract.
const wrong: Specialized["output"] = { answer: "incorrect" };
void [input, output, compatible, wrong];
'''
recursive = '''import * as z from "../../../sources/zod/VARIANT/packages/zod/src/v4/index.ts";
const json = z.json();
type JsonInput = z.input<typeof json>;
type JsonOutput = z.output<typeof json>;
const input: JsonInput = { nested: [null, true, 42, "value", { key: false }] };
const parsed: JsonOutput = json.parse(input);
const nested = z.object({ metadata: json });
nested.parse({ metadata: parsed });
void parsed;
'''
for variant in ("before", "after"):
    directory = HARNESS / "probes" / "zod" / variant
    directory.mkdir(parents=True, exist_ok=True)
    for name, source in [("record-consumer", consumer), ("internal-extension", internal), ("recursive-json", recursive)]:
        (directory / f"{name}.ts").write_text(source.replace("VARIANT", variant))
        config = {"compilerOptions": {"strict": True, "noEmit": True, "allowImportingTsExtensions": True, "module": "ESNext", "moduleResolution": "Bundler", "target": "ES2022", "lib": ["ES2022", "DOM"], "types": [], "skipLibCheck": False}, "files": [f"{name}.ts"]}
        (directory / f"{name}.json").write_text(json.dumps(config, indent=2) + "\n")

(HARNESS / "vitest.config.mts").write_text('''import { defineConfig } from "vitest/config";
export default defineConfig({ test: {
  include: ["sources/hono/before/src/request.test.ts", "sources/hono/after/src/request.test.ts"],
  globals: true, environment: "node", maxWorkers: 1, fileParallelism: false,
  reporters: ["json"], outputFile: "../hono-upstream-node-tests.json",
} });
''')
print("Prepared three compiler probes per revision and a bounded upstream request-test runner.")
