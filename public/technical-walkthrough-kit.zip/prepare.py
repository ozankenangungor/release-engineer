import hashlib
import io
import json
import os
import subprocess
import tarfile
import urllib.request
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
HARNESS = ROOT / "harness"
HARNESS.mkdir(parents=True, exist_ok=True)
ITEMS = [
    ("colinhacks/zod", 6645, "e2e410e447183db267cb94d7ab1892de9e513289", "zod"),
    ("honojs/hono", 5536, "f7d4c67c5b887396b04dd7c09d41855eb0e772fa", "hono"),
]
records = []
for repo, number, expected, name in ITEMS:
    metadata = json.loads(subprocess.check_output(["gh", "api", f"repos/{repo}/pulls/{number}"], text=True))
    assert metadata["head"]["sha"] == expected
    record = {"repository": repo, "prNumber": number, "headSha": expected, "baseSha": metadata["base"]["sha"], "snapshots": []}
    for variant, sha in [("before", record["baseSha"]), ("after", expected)]:
        destination = HARNESS / "sources" / name / variant
        destination.mkdir(parents=True, exist_ok=True)
        raw = subprocess.check_output(["gh", "api", f"repos/{repo}/tarball/{sha}"])
        kept = 0
        with tarfile.open(fileobj=io.BytesIO(raw), mode="r:gz") as archive:
            for member in archive.getmembers():
                relative = Path(*Path(member.name).parts[1:])
                keep = (str(relative).startswith("packages/zod/src/") or str(relative) in {"package.json", "packages/zod/package.json", "LICENSE"}) if name == "zod" else (str(relative).startswith("src/") or str(relative).startswith("runtime-tests/bun/") or str(relative) in {"package.json", "LICENSE"})
                if not keep or not member.isfile():
                    continue
                assert not relative.is_absolute() and ".." not in relative.parts
                target = destination / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                source = archive.extractfile(member)
                assert source is not None
                target.write_bytes(source.read())
                kept += 1
        record["snapshots"].append({"variant": variant, "sha": sha, "archiveSha256": hashlib.sha256(raw).hexdigest(), "retainedSourceFiles": kept})
        print(f"Prepared {name}/{variant}: {sha}, {kept} source/license files", flush=True)
    records.append(record)

bun_url = "https://github.com/oven-sh/bun/releases/download/bun-v1.4.2/bun-linux-x64-baseline.zip"
expected_bun_digest = "c678040f14fe0440eb839d37cbd0ce4c051a32da72806ac97de6a6aab6bf728f"
with urllib.request.urlopen(bun_url, timeout=60) as response:
    raw = response.read()
assert hashlib.sha256(raw).hexdigest() == expected_bun_digest
with zipfile.ZipFile(io.BytesIO(raw)) as archive:
    entries = [name for name in archive.namelist() if name.endswith("/bun")]
    assert len(entries) == 1
    binary = ROOT / "bin" / "bun"
    binary.parent.mkdir(parents=True, exist_ok=True)
    binary.write_bytes(archive.read(entries[0]))
    binary.chmod(0o755)

package = {"name": "release-engineer-upstream-walkthrough", "private": True, "type": "module", "devDependencies": {"ts-legacy": "npm:typescript@5.9.3", "typescript": "7.1.0-dev.20261009.1", "vitest": "5.0.3"}}
(HARNESS / "package.json").write_text(json.dumps(package, indent=2) + "\n")
manifest = {"preparedAtUtc": datetime.now(timezone.utc).isoformat(), "snapshots": records, "bun": {"version": "1.4.2", "assetUrl": bun_url, "assetSha256": expected_bun_digest}, "claudeCalls": 0, "method": "Public source snapshots and publisher binary only; no upstream install/build scripts executed."}
(ROOT / "setup-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print("Source snapshots and digest-verified Bun prepared.", flush=True)
