import hashlib
import json
import os
import platform
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
HARNESS = ROOT / "harness"
allowed = ["PATH", "HOME", "LANG", "LC_ALL", "TZ", "TMPDIR"]
environment = {key: os.environ[key] for key in allowed if key in os.environ}
environment["NODE_ENV"] = "test"
started = datetime.now(timezone.utc).isoformat()

def run(command, timeout=90):
    completed = subprocess.run(command, cwd=HARNESS, env=environment, text=True, capture_output=True, timeout=timeout)
    output = completed.stdout + completed.stderr
    return completed.returncode, output

compilers = [
    ("5.9.3", ["node", "node_modules/ts-legacy/bin/tsc"]),
    ("7.1.0-dev.20261009.1", ["node", "node_modules/typescript/bin/tsc"]),
]
compiler_records = []
for label, executable in compilers:
    code, version = run([*executable, "--version"])
    assert code == 0, version
    assert label in version, f"Compiler executable mismatch: {label} versus {version}"
    for variant in ("before", "after"):
        for probe in ("record-consumer", "internal-extension", "recursive-json"):
            config = f"probes/zod/{variant}/{probe}.json"
            code, output = run([*executable, "--project", config, "--pretty", "false"])
            record = {"compilerPackageVersion": label, "compilerVersionOutput": version.strip(), "variant": variant, "probe": probe, "exitCode": code, "diagnostics": output.replace(str(HARNESS), "<harness>").strip(), "command": [*executable, "--project", config, "--pretty", "false"]}
            compiler_records.append(record)
            print(f"Zod {variant} / TS {label} / {probe}: exit {code}", flush=True)

code, bun_output = run([str(ROOT / "bin" / "bun"), "run", "probes/hono-behavior.ts"])
(ROOT / "hono-bun-probe-output.txt").write_text(bun_output)
bun_record = {"exitCode": code, "command": ["bun@1.4.2", "run", "probes/hono-behavior.ts"], "output": json.loads(bun_output) if code == 0 else bun_output.replace(str(HARNESS), "<harness>")}
print(f"Hono Bun behavior probe: exit {code}", flush=True)

code, vitest_output = run(["node", "node_modules/vitest/vitest.mjs", "run", "--config", "vitest.config.mts"])
(ROOT / "hono-node-test-output.txt").write_text(vitest_output)
upstream = {"exitCode": code, "command": ["node", "node_modules/vitest/vitest.mjs", "run", "--config", "vitest.config.mts"], "diagnostics": vitest_output.replace(str(ROOT), "<walkthrough>").strip()}
report_path = ROOT / "hono-upstream-node-tests.json"
if report_path.exists():
    report = json.loads(report_path.read_text())
    upstream.update({"totalTests": report["numTotalTests"], "passedTests": report["numPassedTests"], "failedTests": report["numFailedTests"], "success": report["success"], "suites": [{"name": entry["name"].replace(str(HARNESS) + "/", ""), "status": entry["status"], "assertions": len(entry["assertionResults"])} for entry in report["testResults"]]})
print(f"Hono upstream Node request tests: exit {code}, {upstream.get('passedTests', 'unknown')} passed", flush=True)

source_manifest = json.loads((ROOT / "setup-manifest.json").read_text())
result = {"schemaVersion": 1, "kind": "assistant_executed_upstream_technical_checks", "startedAtUtc": started, "finishedAtUtc": datetime.now(timezone.utc).isoformat(), "environment": {"platform": platform.system(), "architecture": platform.machine(), "node": subprocess.check_output(["node", "--version"], env=environment, text=True).strip()}, "sourceSnapshots": source_manifest["snapshots"], "bunAsset": source_manifest["bun"], "dependencyLockSha256": hashlib.sha256((HARNESS / "package-lock.json").read_bytes()).hexdigest(), "zodCompilerProbes": compiler_records, "honoBunProbe": bun_record, "honoUpstreamNodeTests": upstream, "claudeCalls": 0, "productionAnalysisRequests": 0, "externalParticipantsEstablished": 0, "qualification": "Assistant-executed source/behavior checks on two public PR snapshots, not a Release Engineer review, a complete compatibility proof, a live Claude evaluation or external user validation. Compiler failures and limited reproductions are retained."}
(ROOT / "observations.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print("Recorded observations.json with every compiler exit and runtime result.", flush=True)
if bun_record["exitCode"] != 0 or upstream["exitCode"] != 0:
    raise SystemExit(1)
