import assert from "node:assert/strict";
import { Hono as BeforeHono } from "../sources/hono/before/src/index.ts";
import { Hono as AfterHono } from "../sources/hono/after/src/index.ts";
import { HonoRequest as BeforeRequest } from "../sources/hono/before/src/request.ts";
import { HonoRequest as AfterRequest } from "../sources/hono/after/src/request.ts";

const results = [];
for (const [variant, Hono, HonoRequest] of [
  ["before", BeforeHono, BeforeRequest], ["after", AfterHono, AfterRequest],
] as const) {
  const request = new HonoRequest(new Request("http://localhost", {
    method: "POST", body: JSON.stringify({ user: { name: "original" } }),
    headers: { "content-type": "application/json" },
  }));
  const first = await request.json<{ user: { name: string } }>();
  first.user.name = "mutated";
  const second = await request.json<{ user: { name: string } }>();
  const json = { sameObject: first === second, secondName: second.user.name };

  let error: string | null = null;
  const app = new Hono().post("/", async (c) =>
    c.text(String((await c.req.formData()).get("name"))));
  app.onError((problem) => {
    error = problem.message;
    return new Response("controlled probe error", { status: 500 });
  });
  const body = new FormData();
  body.append("name", "walkthrough");
  const response = await app.request("/", { method: "POST", body });
  const formData = { status: response.status, text: await response.text(), error };

  // A synthetic failing input stream, not network abort or lazy-boundary cancellation coverage.
  const failedStream = new ReadableStream({
    start(controller) { controller.error(new Error("intentional input-stream failure")); },
  });
  const failedRequest = new HonoRequest(new Request("http://localhost", {
    method: "POST", body: failedStream, duplex: "half",
    headers: { "content-type": "multipart/form-data; boundary=walkthrough" },
  } as RequestInit));
  const failedReads: boolean[] = [];
  for (let i = 0; i < 2; i++) {
    try { await failedRequest.formData(); failedReads.push(false); }
    catch { failedReads.push(true); }
  }
  assert.deepEqual(failedReads, [true, true]);
  if (variant === "before") {
    assert.equal(json.sameObject, true);
    assert.equal(json.secondName, "mutated");
  } else {
    assert.equal(json.sameObject, false);
    assert.equal(json.secondName, "original");
    assert.equal(formData.status, 200);
    assert.equal(formData.text, "walkthrough");
  }
  results.push({ variant, json, formData, failedInputReadsRejected: failedReads });
}
console.log(JSON.stringify({
  runtime: `Bun ${Bun.version}`, kind: "assistant_executed_upstream_behavior_probe",
  claudeCalls: 0, networkRequestsByProbe: 0, results,
  limitation: "Three constructed in-process request objects per revision; no end-to-end product use, participant validation or lazy-boundary network-abort coverage.",
}, null, 2));
